---
name: Luminous Pearl
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#3d4947'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#525e5c'
  on-tertiary: '#ffffff'
  tertiary-container: '#6b7775'
  on-tertiary-container: '#f3fffc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#d8e5e2'
  tertiary-fixed-dim: '#bcc9c6'
  on-tertiary-fixed: '#121e1c'
  on-tertiary-fixed-variant: '#3d4947'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Epilogue
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Epilogue
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Epilogue
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style
The design system is a high-end, light-mode interface that evokes the clarity and radiance of a polished pearl. It serves as a direct counterpart to dark-themed "liquid vault" aesthetics, transitioning from deep obsidian to an ethereal, luminous atmosphere. 

The personality is **sophisticated, serene, and editorial**. It targets premium audiences in finance, wellness, or luxury technology who value clarity and a sense of "digital calm." The style is a refined hybrid of **Glassmorphism** and **Minimalism**, utilizing translucent white layers, soft-focus blurs, and subtle inner glows to create depth without visual clutter. The interface should feel like light passing through frosted glass—soft, diffused, and high-quality.

## Colors
The palette is built on a foundation of "luminous surfaces" and "liquid accents."

- **Surfaces:** The primary background is an off-white (`#F8FAFC`). Layered surfaces use a very pale mint-teal (`#F0FDFA`) with 80% opacity to allow background colors to bleed through subtly.
- **Primary Accent:** A refined, accessible teal (`#0D9488`) used for primary actions and brand presence.
- **Secondary Accent:** A sapphire blue (`#2563EB`) reserved for interactive states, links, and specialized data visualization.
- **Functional Gradients:** Use subtle linear gradients for "liquid" effects, moving from Primary Teal to Secondary Sapphire at a 135-degree angle with high transparency.

## Typography
The typography strategy balances editorial character with modern legibility. 

**Epilogue** is utilized for headlines to provide a geometric, distinctive structure that feels premium and intentional. For body text and functional labels, **Plus Jakarta Sans** provides a soft, approachable, and highly readable experience. 

Text colors should never be pure black; use a deep charcoal-teal (`#134E4A`) for headlines and a muted slate-gray (`#475569`) for body text to maintain the "Luminous Pearl" softness.

## Layout & Spacing
The layout follows a **fluid grid** model with generous white space to emphasize the "Luminous" quality.

- **Grid:** 12-column system for desktop, 4-column for mobile.
- **Rhythm:** An 8px base unit governs all padding and margins. 
- **Reflow:** On mobile, margins tighten to 20px, and vertical spacing between "Glass" cards increases to 32px to maintain a sense of separation and breathability.
- **Safe Areas:** Interactive elements must maintain a minimum 48px touch target height, even when visually appearing smaller.

## Elevation & Depth
Depth is achieved through **optical transparency** rather than heavy shadows.

- **Glassmorphism:** Use a `backdrop-filter: blur(12px)` on all floating containers. Background colors for these containers should be white at 70% opacity.
- **Inner Glows:** To simulate the pearl effect, apply a 1px white inner border (stroke) at 50% opacity and a very soft `inset` white shadow to the top-left edge of components.
- **Outer Shadows:** Use "Ambient Shadows"—ultra-diffused, low-opacity (#0D9488 at 8% alpha) with a large blur radius (20px-40px) to make elements appear to float on a bed of light.

## Shapes
The shape language is organic and approachable. This design system uses the **Rounded** (0.5rem base) setting to ensure all corners feel soft to the touch. 

- **Standard Elements:** 0.5rem (8px) for buttons and inputs.
- **Cards/Containers:** 1rem (16px) for main content areas.
- **Large Floating Sections:** 1.5rem (24px) for modals and large surface areas.
- **Interactive States:** On hover, slightly increase the "inner glow" intensity rather than changing the corner radius.

## Components
- **Buttons:** Primary buttons use the Teal-to-Sapphire liquid gradient with white text. Secondary buttons are "Ghost Glass"—transparent with a 1px teal border and subtle blur.
- **Input Fields:** Semi-transparent white backgrounds with a 1px border that glows (Primary Teal) on focus. Labels sit 4px above the field in `label-sm`.
- **Cards:** The signature "Pearl Card" features a 16px corner radius, 12px backdrop blur, and a subtle 1px white inner stroke. 
- **Chips/Badges:** Use "Frosted" fills—very pale teal backgrounds with dark teal text. No borders.
- **Lists:** Separated by thin, 1px horizontal lines using a 10% opacity version of the primary teal.
- **Glass Modals:** Full-screen overlays should use a background blur of 20px with a 40% white tint to maintain the light-mode theme while focusing the user.